export const ONCHAIN_BIO = "0x1::bio";
