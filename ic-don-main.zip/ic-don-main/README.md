# 🌐 IC-Don: Decentralized Oracle Network

![IC-Don Logo](public/logo/ic-don.png)

Welcome to **IC-Don**, a **decentralized oracle network** and EigenLayer hackathon-winning project! Built on the **Internet Computer (ICP)** with integrations for **EigenLayer** and **Aptos**, IC-Don delivers secure, reliable, and high-performance data feeds for blockchain applications. Leveraging **ICP Chain Fusion**, IC-Don ensures seamless interoperability between Ethereum and ICP networks, making it a robust solution for trusted data delivery in decentralized applications (dApps). 🚀

---

## 🌟 Why IC-Don?

IC-Don solves the critical challenge of **trusted data delivery** in decentralized ecosystems. By combining the power of ICP’s scalability, EigenLayer’s restaking security, and Aptos’ high-performance blockchain, IC-Don provides a user-friendly, secure, and efficient oracle network for dApps. Whether you're building DeFi, gaming, or other blockchain solutions, IC-Don ensures your smart contracts have access to reliable off-chain data.

---

## 🔑 Key Features

- **Decentralized Oracle Network**: Secure and reliable data feeds for blockchain applications. 🔒
- **ICP Chain Fusion**: Smart contracts deployed on ICP for high performance and Ethereum interoperability. 🌉
- **EigenLayer Integration**: Enhanced security through Ethereum’s restaking mechanism. 🛡️
- **Aptos Integration**: High-speed, reliable data processing for real-time applications. ⚡
- **User-Friendly Interface**: Intuitive frontend for seamless interaction with the oracle network. 🎨
- **Scalable and Modular**: Easily extensible for new integrations and use cases. 🧩

---

## 📂 Project Structure

The IC-Don repository is organized for clarity and ease of development:

```
ic-don/
├── .devcontainer/                  # Development environment configuration
├── backend/                        # Backend server and services
│   ├── src/
│   │   ├── config/                 # Configuration files
│   │   │   └── aptosConfig.js
│   │   ├── services/               # Core backend logic
│   │   │   ├── contractInteractor.js
│   │   │   ├── dataFetcher.js
│   │   │   └── index.js
│   ├── package.json
├── canisters/                      # ICP canister code
│   └── chain_fusion/
├── client/                         # Next.js frontend
│   ├── public/                     # Static assets
│   ├── src/
│   │   ├── app/                    # Core app files
│   │   │   ├── layout.tsx
│   │   │   ├── page.tsx
│   │   ├── components/             # Reusable UI components
│   │   │   ├── transactionFlows/   # Transaction-related components
│   │   │   │   ├── MultiAgent.tsx
│   │   │   │   ├── SingleSigner.tsx
│   │   │   │   ├── Sponsor.tsx
│   │   │   │   └── TransactionParameters.tsx
│   │   │   ├── ui/                 # UI component library
│   │   │   │   ├── alert.tsx
│   │   │   │   ├── button.tsx
│   │   │   │   ├── card.tsx
│   │   │   │   └── more...
│   │   │   ├── AutoConnectProvider.tsx
│   │   │   ├── WalletProvider.tsx
│   │   ├── constants/              # Constants and configuration
│   │   ├── styles/                 # CSS and Tailwind configuration
│   │   ├── utils/                  # Utility functions
├── contracts/                      # Smart contracts
│   ├── EigenLayerOracle.sol        # Core oracle contract
│   ├── Randomness.sol              # Randomness generation contract
├── lib/                            # Shared libraries
├── packages/                       # Additional packages
├── script/                         # Deployment scripts
│   ├── EigenLayerOracle.s.sol
│   ├── Randomness.s.sol
├── .gitignore
├── Caddyfile                       # Web server configuration
├── Cargo.toml                      # Rust dependencies
├── dfx.json                        # ICP canister configuration
├── foundry.toml                    # Foundry configuration
├── deploy.sh                       # Deployment script
├── README.md
```

---

## 🚀 Getting Started

Follow these steps to set up and run IC-Don locally:

### Prerequisites
- **Node.js**: v18 or higher
- **Rust**: Latest stable version
- **DFX**: Internet Computer SDK (for canister deployment)
- **pnpm**: Recommended package manager
- **Foundry**: For smart contract development and testing

### Installation

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/arhansuba/ic-don.git
   cd ic-don
   ```

2. **Install Backend Dependencies**:
   ```bash
   cd backend
   pnpm install
   ```

3. **Install Frontend Dependencies**:
   ```bash
   cd ../client
   pnpm install
   ```

### Running the Application

1. **Start the Backend**:
   ```bash
   cd backend
   pnpm start
   ```

2. **Start the Frontend**:
   ```bash
   cd client
   pnpm start
   ```
   Open `http://localhost:3000` in your browser to access the frontend.

3. **Deploy Canisters** (for ICP integration):
   ```bash
   dfx start --background
   dfx deploy
   ```

### Configuration

- **Backend**: Configure the backend in `backend/src/config/aptosConfig.js`. Update API endpoints, network settings, or other parameters as needed.
- **Frontend**: Adjust settings in `client/src/constants/constants.ts` for wallet providers, network configurations, etc.
- **Canisters**: Modify `dfx.json` for ICP canister configurations.

---

## 🧪 Smart Contracts

The smart contracts are located in the `contracts/` directory:

- **EigenLayerOracle.sol**: The core oracle contract, integrating with EigenLayer for secure data feeds.[](https://github.com/arhansuba/ic-don)
- **Randomness.sol**: Generates secure randomness for dApps.

### Testing Contracts
Run tests for the smart contracts using Foundry:
```bash
cd contracts
forge test
```

### Deploying Contracts
Deploy contracts using the provided scripts:
```bash
cd script
forge script EigenLayerOracle.s.sol --broadcast
forge script Randomness.s.sol --broadcast
```

---

## 🛡️ Security & Integrations

IC-Don leverages advanced blockchain technologies for security and interoperability:

- **ICP Chain Fusion**: Enables high-performance smart contract deployment and Ethereum interoperability.[](https://github.com/arhansuba/ic-don)
- **EigenLayer**: Provides restaking for enhanced security and scalability.[](https://github.com/arhansuba/ic-don)
- **Aptos**: Ensures high-throughput, reliable data processing.[](https://github.com/arhansuba/ic-don)

All data feeds are cryptographically verified to ensure integrity and reliability.

---

## 📸 Screenshots

Explore IC-Don’s intuitive interface:

| ![Dashboard](public/screenshots/dashboard.png) | ![Data Feed](public/screenshots/data-feed.png) |
|-----------------------------------------------|-----------------------------------------------|
| ![Wallet Connect](public/screenshots/wallet.png) | ![Transaction](public/screenshots/transaction.png) |

*(Note: Replace with actual screenshot paths once available.)*

---

## 🤝 Contributing

We welcome contributions to IC-Don! To get involved:

1. Read our [Contribution Guidelines](https://github.com/arhansuba/ic-don/blob/main/CONTRIBUTING.md).
2. Open an issue or submit a pull request on [GitHub](https://github.com/arhansuba/ic-don).
3. Join our community on [Discord](https://discord.gg/your-community) for discussions.

---


## 🎉 Join the Community

Stay connected with IC-Don:

- **GitHub**: [arhansuba/ic-don](https://github.com/arhansuba/ic-don)
- **Discord**: [Join our community](https://discord.gg/your-community) 💬
- **Website**: [Coming soon](https://ic-don.space)

Thank you for exploring **IC-Don**! We’re excited to empower dApps with secure and reliable data feeds. 😊