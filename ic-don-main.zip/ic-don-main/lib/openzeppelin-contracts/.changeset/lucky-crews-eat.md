---
'openzeppelin-solidity': minor
---

`Votes`: Set `_moveDelegateVotes` visibility to internal instead of private.
