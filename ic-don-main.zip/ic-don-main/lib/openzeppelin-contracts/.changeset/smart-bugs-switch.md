---
'openzeppelin-solidity': minor
---

`Math`: Custom errors replaced with native panic codes.
