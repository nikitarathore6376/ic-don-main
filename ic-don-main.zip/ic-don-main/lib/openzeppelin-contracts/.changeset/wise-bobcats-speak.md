---
'openzeppelin-solidity': minor
---

`VestingWalletCliff`: Add an extension of the `VestingWallet` contract with an added cliff.
