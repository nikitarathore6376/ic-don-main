---
'openzeppelin-solidity': minor
---

`Base64`: Add `encodeURL` following section 5 of RFC4648 for URL encoding
