---
'openzeppelin-solidity': minor
---

`CircularBuffer`: Add a data structure that stores the last `N` values pushed to it.
