---
'openzeppelin-solidity': minor
---

`Arrays`: add a `sort` functions for `address[]`, `bytes32[]` and `uint256[]` memory arrays.
