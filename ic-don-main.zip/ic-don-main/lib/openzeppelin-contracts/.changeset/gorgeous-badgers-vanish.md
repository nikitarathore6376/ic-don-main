---
'openzeppelin-solidity': minor
---

`SlotDerivation`: Add a library of methods for derivating common storage slots.
