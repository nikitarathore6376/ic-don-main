---
'openzeppelin-solidity': minor
---

`Math`, `SignedMath`: Add a branchless `ternary` function that computes`cond ? a : b` in constant gas cost.
