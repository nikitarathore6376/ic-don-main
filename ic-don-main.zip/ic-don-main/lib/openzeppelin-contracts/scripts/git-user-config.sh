#!/usr/bin/env bash

set -euo pipefail -x

git config user.name 'github-actions'
git config user.email '41898282+github-actions[bot]@users.noreply.github.com'
